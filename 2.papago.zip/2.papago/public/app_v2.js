const textAreaArray = document.getElementsByClassName('Card__body__content');
const [sourceTextArea, targetTextArea] = textAreaArray;
const [sourceSelect, targetSelect] = document.getElementsByClassName('form-select');

let targetLanguage = 'en';

targetSelect.addEventListener('change', () => {
    targetLanguage = targetSelect.value;
});

let debouncer; // 디바운싱 & 쓰로틀링
sourceTextArea.addEventListener('input', (event) => {
    if (debouncer) clearTimeout(debouncer);

    debouncer = setTimeout(async () => {
        const text = event.target.value; // 번역할 텍스트
        if (!text) return

        const url = '/detect';

        await fetch(url, optionsFrom('POST', { query: text }))
            .then(response => response.json())
            .then(async data => {
                // 자동 언어 감지 부분을 ko면 한국어로, en이면 English로 Select박스가 변할 수 있도록
                const sourceLanguage = data.langCode;
                sourceSelect.value = sourceLanguage;

                if (sourceLanguage === targetLanguage) { // 원본 언어와 타겟 언어가 서로 같고,
                    if (sourceLanguage === 'ko') { // 원본 언어가 한국어일 경우
                        targetLanguage = 'en'; // 타겟 언어를 영어로 변경
                    } else { // 원본 언어가 한국어가 아닐 경우
                        targetLanguage = 'ko'; // 타겟 언어를 한국어로 변경
                    }
                }

                // 언어 번역 요청 전송 코드 작성
                const url = '/translate';
                const body = {
                    source: sourceLanguage,
                    target: targetLanguage,
                    text,
                };

                await fetch(url, optionsFrom('POST', body))
                    .then(response => response.json())
                    .then(data => {
                        const result = data.message.result;
                        targetTextArea.value = result.translatedText;
                        targetSelect.value = result.tarLangType; // ??
                    })
                    .catch(error => console.error(error));

            })
            .catch(error => console.error(error));
    }, 2 * 1000);

});

// 유틸 메서드
const optionsFrom = (method, body, headers) => {
    return {
        method,
        headers: {
            'Content-Type': 'application/json',
            ...headers,
        },
        body: JSON.stringify(body),
    };
}