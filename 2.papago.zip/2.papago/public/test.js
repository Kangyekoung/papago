const textAreaArray = document.getElementsByClassName('Card__body__content');
const [sourceTextArea, targetTextArea] = textAreaArray;
const [sourceSelect, targetSelect] = document.getElementsByClassName('form-select');

let targetLanguage = 'en';

targetSelect.addEventListener('change', () => {
    targetLanguage = targetSelect.value;
});

let debouncer;
sourceTextArea.addEventListener('input', (event) => {
    if (debouncer) {
        clearTimeout(debouncer);
    }

    debouncer = setTimeout(async () => {
        const text = event.target.value;
        if (!text) return

        const url = '/detect';
        await fetch(url, optionsFrom('POST', { query: text }))
            .then(response => response.json())
            .then(async data => {
                const sourceLanguage = data.langCode;
                sourceSelect.value = sourceLanguage;

                if (sourceLanguage === targetLanguage) { // 원본 언어와 타겟 언어의 언어가 서로 같고,
                    if (sourceLanguage === 'ko') { // 원본 언어가 한국어일 경우,
                        targetLanguage = 'en'; // 타겟 언어를 영어로 변경
                    } else { // 원본 언어가 한국어가 아닐 경우,
                        targetLanguage = 'ko'; // 타겟 언어를 한국어로 변경
                    }
                }

                const body = {
                    source: sourceLanguage,
                    target: targetLanguage,
                    text,
                };

                const url = '/translate';
                await fetch(url, optionsFrom('POST', body))
                    .then(response => response.json())
                    .then(data => {
                        const result = data.message.result;
                        targetTextArea.value = result.translatedText;
                        targetSelect.value = result.tarLangType;
                    })
                    .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, 2000);

});

// 유틸 메서드
const optionsFrom = (method, body, headers) => {
    return {
        method,
        headers: { 'Content-Type': 'application/json', ...headers },
        body: JSON.stringify(body),
    }
};