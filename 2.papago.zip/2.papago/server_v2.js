// Node.js, Express 패키지를 활용하여 간단한 서버 구성
const express = require('express');
const app = express();

const clientId = 'FB1Fyk3tdgXRw5VDMvgl';
const clientSecret = 'zJx5ZDDcBG';

const httpRequest = require('request');

app.use(express.static('public'));
app.use(express.json());

// localhost:3000/
app.get('/', (request, response) => {
    response.sendFile('index.html');
});

// localhost:3000/detect
app.post('/detect', (request, response) => {
    const url = 'https://openapi.naver.com/v1/papago/detectLangs';

    httpRequest.post(optionsFrom(url, request.body), (error, httpResponse, body) => {
        if (!error && response.statusCode === 200) {
            response.send(body); // {"langCode":"ko"}
        }
    });

});

// localhost:3000/translate
app.post('/translate', (request, response) => {
    const url = 'https://openapi.naver.com/v1/papago/n2mt';

    httpRequest.post(optionsFrom(url, request.body), (error, httpResponse, body) => {
        if (!error && response.statusCode === 200) {
            response.send(body);
        }
    });

});

const port = 3000;
app.listen(port, () => console.log(`http://127.0.0.1:3000/ app listening on port ${port}`));

// 유틸 메서드
const optionsFrom = (url, form, headers) => {
    return {
        url,
        form,
        headers: {
            'Content-Type': 'application/json',
            'X-Naver-Client-Id': clientId,
            'X-Naver-Client-Secret': clientSecret,
            ...headers,
        },
    }
};